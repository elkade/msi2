/**
 * Provides various plugins for neural networks.
 */

package org.neuroph.util.plugins;