/**
 * Provides neural network learning events system
 */

package org.neuroph.core.events;
